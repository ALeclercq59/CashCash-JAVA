/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientlourd;

import java.util.ArrayList;

/**
 *
 * @author ZBoum
 */
public class ContratMaintenance {
    private String numContrat;
    private DateTp dateSignature;
    private DateTp dateEcheance;
    private Client unClient;
    private TypeContrat unTypeContrat;
    private ArrayList<Materiel> lesMaterielsAssures;
    private ArrayList<Materiel> lesMaterielsNonAssures;

    
    public ContratMaintenance(String numContrat, DateTp dateSignature, DateTp dateEcheance, TypeContrat unTypeContrat) 
    {
        this.numContrat = numContrat;
        this.dateSignature = dateSignature;
        this.dateEcheance = dateEcheance;
        this.unTypeContrat = unTypeContrat;
        this.lesMaterielsAssures = new ArrayList<>();
        this.lesMaterielsNonAssures = new ArrayList<>();
        this.unClient = null;
    }
    
    public long getJoursRestants(){
    	DateTp aujourdhui = DateTp.aujourdhui();
        return dateEcheance.difference(aujourdhui);
    }
    
    public boolean estValide(){
        DateTp aujourdhui = DateTp.aujourdhui();
        if(aujourdhui.difference(dateSignature) > 0 && aujourdhui.difference(dateEcheance) <= 0){
            return true;
        }
        else
        {
        	return false;
        }
    }
    
    public void ajouteMaterielAssure(Materiel unMateriel){
        if(dateSignature.difference(unMateriel.getDateInstallation()) < 0 && this.estValide()){
            lesMaterielsAssures.add(unMateriel);
        }
       else
        {
        	lesMaterielsNonAssures.add(unMateriel);
        }
    }

    public String getNumContrat() {
        return numContrat;
    }

    public void setNumContrat(String numContrat) {
        this.numContrat = numContrat;
    }

    public DateTp getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(DateTp dateSignature) {
        this.dateSignature = dateSignature;
    }

    public DateTp getDateEcheance() {
        return dateEcheance;
    }

    public void setDateEcheance(DateTp dateEcheance) {
        this.dateEcheance = dateEcheance;
    }

    public ArrayList<Materiel> getLesMaterielsAssures() {
        return lesMaterielsAssures;
    }

    public void setLesMaterielsAssures(ArrayList<Materiel> lesMaterielsAssures) {
        this.lesMaterielsAssures = lesMaterielsAssures;
    }
       
    public ArrayList<Materiel> getLesMaterielsNonAssures() {
        return lesMaterielsNonAssures;
    }

    public void setLesMaterielsNonAssures(ArrayList<Materiel> lesMaterielsNonAssures) {
        this.lesMaterielsNonAssures = lesMaterielsNonAssures;
    }

	public TypeContrat getUnTypeContrat() {
		return unTypeContrat;
	}

	public void setUnTypeContrat(TypeContrat unTypeContrat) {
		this.unTypeContrat = unTypeContrat;
	}

	public Client getUnClient() {
		return unClient;
	}

	public void setUnClient(Client unClient) {
		this.unClient = unClient;
	}
}
