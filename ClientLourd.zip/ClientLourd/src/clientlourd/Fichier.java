package clientlourd;

import java.io.*;
public class Fichier {
	    private BufferedWriter fW ;
	    private BufferedReader fR ;
	    private char mode ;
	    
	    public void ouvrir(String nomFichier, String modeOuverture)throws IOException
	    {
	        mode = modeOuverture.charAt(0);
	        File f = new File(nomFichier);
	        if(mode == 'r' || mode == 'l'){
	            fR = new BufferedReader(new FileReader(f));
	        }
	        if(mode == 'w' || mode == 'e'){
	            fW = new BufferedWriter(new FileWriter(f));
	        }
	    }
	    
	    public void ecriture (String tmp) throws IOException 
	    {
		    fW.write (tmp) ;
	    }
	    
	    
	    public String lire () throws IOException 
	    {
	    	String chaine = fR.readLine();
	        return chaine ;
	    }

	    public void fermer () throws IOException 
	    {
		if ( mode == 'r' || mode == 'l' ) 
	        {
			fR.close () ;
		}
		if ( mode == 'w' || mode == 'e' ) 
	        {
			fW.close () ;
		}
		
	    }
}
