package clientlourd;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class FicheClient extends JFrame {

	private JPanel contentPane;
	
	private static String id;
	
	PersistanceSQL pSQL = new PersistanceSQL ("localhost", 3306, "cashcash");
	
	GestionMateriels gm = new GestionMateriels(pSQL);

	/**
	 * Create the frame.
	 */
	public FicheClient(Client client) {
		setResizable(false);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 748, 471);
		contentPane = new JPanel();
		contentPane.setBorder(null);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Fiche Client n�" + client.getNumClient());
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 24));
		lblNewLabel_1.setBounds(255, 11, 260, 30);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Nom : " + client.getNom());
		lblNewLabel_2.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(68, 104, 232, 23);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblPrnom = new JLabel("Pr\u00E9nom : " + client.getPrenom());
		lblPrnom.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblPrnom.setBounds(68, 148, 232, 23);
		contentPane.add(lblPrnom);
		
		JLabel lblTlphone = new JLabel("T\u00E9l\u00E9phone : " + client.getTelClient());
		lblTlphone.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblTlphone.setBounds(68, 190, 232, 23);
		contentPane.add(lblTlphone);
		
		JLabel lblAdresse = new JLabel("Adresse : " + client.getAdresse());
		lblAdresse.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblAdresse.setBounds(68, 236, 268, 23);
		contentPane.add(lblAdresse);
		
		JLabel lblRaisonSociale = new JLabel("Raison Sociale : " + client.getRaisonSociale());
		lblRaisonSociale.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblRaisonSociale.setBounds(425, 104, 268, 23);
		contentPane.add(lblRaisonSociale);
		
		JLabel lblSiren = new JLabel("SIREN : " + client.getSiren());
		lblSiren.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblSiren.setBounds(425, 148, 268, 23);
		contentPane.add(lblSiren);
		
		JLabel lblCodeApe = new JLabel("Code APE : " + client.getSiren());
		lblCodeApe.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblCodeApe.setBounds(425, 190, 268, 23);
		contentPane.add(lblCodeApe);
		
		JLabel lblFax = new JLabel("Fax : " + client.getFax());
		lblFax.setFont(new Font("Calibri", Font.PLAIN, 16));
		lblFax.setBounds(425, 236, 268, 23);
		contentPane.add(lblFax);
		
		JButton button = new JButton("Voir Contrat");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				ContratClient c = new ContratClient(client);
				c.setVisible(true);
				
			}
		});
		button.setFont(new Font("Calibri", Font.PLAIN, 20));
		button.setBounds(85, 340, 159, 30);
		contentPane.add(button);
		
		button.setBounds(117, 340, 159, 30);
		contentPane.add(button);
		
		JButton btnNewButton = new JButton("Retour");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				Accueil a = new Accueil ();
				a.frame.setVisible(true);
			}
		});
		btnNewButton.setBounds(654, 408, 78, 23);
		contentPane.add(btnNewButton);
		
		JButton btnVoirMatriels = new JButton("Voir Mat\u00E9riel(s)");
		btnVoirMatriels.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				MaterielsClient mc = new MaterielsClient (client);
				mc.setVisible(true);
			}
		});
		btnVoirMatriels.setFont(new Font("Calibri", Font.PLAIN, 20));
		btnVoirMatriels.setBounds(303, 340, 177, 30);
		contentPane.add(btnVoirMatriels);
		
		JButton btnCrerFicheXml = new JButton("Cr\u00E9er Fiche XML");
		btnCrerFicheXml.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					gm.creerXml(Integer.parseInt(client.getNumClient()));
					JOptionPane.showMessageDialog(null,  "Cr�ation de la fiche xml pour le client n� " + client.getNumClient(), "R�ussite", JOptionPane.INFORMATION_MESSAGE);
				
				} catch (SQLException e1) {
					JOptionPane.showMessageDialog(null,  "XML non valide pour le client n� " + client.getNumClient(), "Erreur", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnCrerFicheXml.setFont(new Font("Calibri", Font.PLAIN, 20));
		btnCrerFicheXml.setBounds(498, 340, 195, 30);
		contentPane.add(btnCrerFicheXml);
		
		JButton btnEnvoyerMail = new JButton("Envoyer Mail");
		btnEnvoyerMail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println(client.getEmail());
				PDFGenerator.creerPDF(client);
				Mail test = new Mail(client.getEmail(), "Contrat", "");
			}
		});
		btnEnvoyerMail.setFont(new Font("Calibri", Font.PLAIN, 20));
		btnEnvoyerMail.setBounds(303, 400, 177, 30);
		contentPane.add(btnEnvoyerMail);
		
		if (client.getLeContrat() != null)
		{
			button.setVisible(true);
		}
		else
		{
			button.setVisible(false);
		}
		
	}
}
