/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientlourd;

/**
 *
 * @author ZBoum
 */
public class Materiel {
    private int numSerie;
    private DateTp dateVente;
    private DateTp dateInstallation;
    private double prixVente;
    private String emplacement;
    private TypeMateriel leType;
    private Client leClient;
    private ContratMaintenance leContrat;
    
    Materiel (int numSerie, DateTp dateVente, DateTp dateInstallation, double prixVente, String emplacement, TypeMateriel leType)
    {
        this.numSerie = numSerie;
        this.dateVente = dateVente;
        this.dateInstallation = dateInstallation;
        this.prixVente = prixVente;
        this.emplacement = emplacement;
        this.leType = leType;
        this.leClient = leClient;
        this.leContrat = null;
    }
    
    public String xmlMateriel(){
    	String newLine = System.getProperty("line.separator");
    	String xml;
    	xml = "<materiel numSerie=\"" + numSerie + "\">" + newLine;
    	xml += "<type refInterne=\"" + leType.getReferenceInterne() + "\" libelle=\"" + leType.getLibelleTypeMateriel() + "\"/>" + newLine; 
    	xml +=	"<famille codeFamille=\"" + leType.getLaFamille().getCodeFamille() + "\" libelle=\"" + leType.getLaFamille().getLibelleFamille() + "\"/>" + newLine;
    	xml +=	"<date_vente>" + dateVente.afficheDateC() + "</date_vente>"  + newLine;
    	xml += 	"<date_installation>" + dateInstallation.afficheDateC() + "</date_installation>" + newLine;
    	xml +=	"<prix_vente>" + prixVente + "</prix_vente>" + newLine ;
    	xml +=	"<emplacement>\"" + emplacement + "\"</emplacement>" + newLine;
    	if (leClient.getLeContrat() != null && leClient.getMaterielsSousContrat().contains(this))
    	{
    		xml += "<nbJoursAvantEcheance>" + leClient.getLeContrat().getJoursRestants() + "</nbJoursAvantEcheance>" + newLine;
    	}
    	xml +=	"</materiel>"  + newLine ;
    	
    	return xml;
    }

    public int getNumSerie() {
        return numSerie;
    }

    public void setNumSerie(int numSerie) {
        this.numSerie = numSerie;
    }

    public DateTp getDateVente() {
        return dateVente;
    }

    public void setDateVente(DateTp dateVente) {
        this.dateVente = dateVente;
    }

    public DateTp getDateInstallation() {
        return dateInstallation;
    }

    public void setDateInstallation(DateTp dateInstallation) {
        this.dateInstallation = dateInstallation;
    }

    public double getPrixVente() {
        return prixVente;
    }

    public void setPrixVente(double prixVente) {
        this.prixVente = prixVente;
    }

    public String getEmplacement() {
        return emplacement;
    }

    public void setEmplacement(String emplacement) {
        this.emplacement = emplacement;
    }

    public TypeMateriel getLeType() {
        return leType;
    }

    public void setLeType(TypeMateriel leType) {
        this.leType = leType;
    }

	public Client getLeClient() {
		return leClient;
	}

	public void setLeClient(Client leClient) {
		this.leClient = leClient;
	}

	public ContratMaintenance getLeContrat() {
		return leContrat;
	}

	public void setLeContrat(ContratMaintenance leContrat) {
		this.leContrat = leContrat;
	}
    
    
    
}
