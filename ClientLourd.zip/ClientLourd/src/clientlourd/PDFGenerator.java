package clientlourd;

import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.util.ArrayList;

import com.qoppa.pdfWriter.PDFDocument;
import com.qoppa.pdfWriter.PDFGraphics;
import com.qoppa.pdfWriter.PDFPage;

public class PDFGenerator {
	
	PersistanceSQL pSQL = new PersistanceSQL ("localhost", 3306, "cashcash");
	
    public static void creerPDF(Client c)
    {
    	try
        {
            // Create a document and a page in default Locale format
            PDFDocument pdfDoc = new PDFDocument();
            PDFPage newPage = pdfDoc.createPage(new PageFormat());
            
            // Draw to the page
            Graphics2D g2d = newPage.createGraphics();
            g2d.setFont (PDFGraphics.HELVETICA.deriveFont(24f));
            g2d.drawString("Fiche Relance", 235, 100);
            g2d.setFont (PDFGraphics.HELVETICA.deriveFont(10f));
            g2d.drawString("Num�ro Client : " + c.getNumClient(), 100, 125);
            g2d.setFont (PDFGraphics.HELVETICA.deriveFont(12f));
            g2d.drawString("Madame, Monsieur " + c.getNom() + " " + c.getPrenom() + ",", 100, 160);
            
            if (c.getLeContrat() != null && c.getLeContrat().estValide())
            {
            	g2d.drawString("Votre contrat n� " + c.getLeContrat().getNumContrat() + " arrive � �ch�ance le " + c.getLeContrat().getDateEcheance().afficheDateC() + ", ce qui signifie que vos mat�riels", 100, 200);
                g2d.drawString("ne seront plus assur�s par nos services.", 100, 220);
                g2d.drawString("Veuillez nous recontacter si vous voulez un renouvellement de votre contrat.", 100, 260);
                g2d.drawString("Cordialement, La Direction.", 100, 300);
            }
            else if (c.getLeContrat() != null && !c.getLeContrat().estValide())
            {
            	g2d.drawString("Votre contrat n� " + c.getLeContrat().getNumContrat() + " est arriv� � �ch�ance le " + c.getLeContrat().getDateEcheance().afficheDateC() + ", ce qui signifie que vos", 100, 200);
                g2d.drawString("mat�riels ne sont plus assur�s.", 100, 220);
                g2d.drawString("Veuillez nous recontacter si vous souhaitez un renouvellement de votre contrat.", 100, 250);
                g2d.drawString("Cordialement, La Direction.", 100, 300);
            }
            else if (c.getLeContrat() == null)
            {
            	g2d.drawString("Vous n'avez pas de contrat chez nous alors que vous avez plusieurs mat�riels", 100, 200);
                g2d.drawString("install�.", 100, 220);
                g2d.drawString("Veuillez nous recontacter si vous souhaitez sign� contrat chez nous.", 100, 250);
                g2d.drawString("Cordialement, La Direction.", 100, 300);
            }
            
            // Add the page to the document and save it
            pdfDoc.addPage(newPage);
            pdfDoc.saveDocument("materielClientPDF/PDFClientRelance.pdf");
        }
        catch (Throwable t)
        {
            t.printStackTrace();
        }
    }

}


