/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientlourd;

import java.util.ArrayList;

/**
 *
 * @author ZBoum
 */
public class Client {
   private String numClient;
   private String raisonSociale;
   private String nom;
   private String prenom;
   private String siren;
   private String fax;
   private String codeApe;
   private String adresse;
   private String telClient;
   private String email;
   private String numeroAgence;
   private int dureeDeplacement;
   private int distanceKm;
   private ArrayList<Materiel> lesMateriels;
   private ContratMaintenance leContrat;
   
   Client (String numClient, String nom, String prenom, String raisonSociale, String siren, String codeApe, String adresse, String telClient, String fax, String email, int dureeDeplacement, int distanceKm, String numeroAgence)
   {
       this.numClient = numClient;
       this.nom = nom;
       this.prenom = prenom;
       this.raisonSociale = raisonSociale;
       this.siren = siren;
       this.codeApe = codeApe;
       this.adresse = adresse;
       this.telClient = telClient;
       this.fax = fax;
       this.email = email;
       this.numeroAgence = numeroAgence;
       this.dureeDeplacement = dureeDeplacement;
       this.distanceKm = distanceKm;
       this.lesMateriels = new ArrayList<>();
       this.leContrat = null;
   }
   
public ArrayList<Materiel> getMateriel(){
       return lesMateriels;
   }
   
   public ArrayList<Materiel> getMaterielsSousContrat(){
       return leContrat.getLesMaterielsAssures();
   }
   
   public ArrayList<Materiel> getMaterielsHorsContrat(){
       return leContrat.getLesMaterielsNonAssures();
   }
   
   public boolean estAssure()
   {
	   if (leContrat.estValide())
	   {
		   return true; 
	   }
	   else
       {
       		return false;
       }
   }
   
   public void ajouteMateriel(Materiel unMateriel)
   {
	   lesMateriels.add(unMateriel);
   }

public String getNumClient() {
	return numClient;
}

public void setNumClient(String numClient) {
	this.numClient = numClient;
}

public String getRaisonSociale() {
	return raisonSociale;
}

public void setRaisonSociale(String raisonSociale) {
	this.raisonSociale = raisonSociale;
}

public String getSiren() {
	return siren;
}

public void setSiren(String siren) {
	this.siren = siren;
}

public String getCodeApe() {
	return codeApe;
}

public void setCodeApe(String codeApe) {
	this.codeApe = codeApe;
}

public String getAdresse() {
	return adresse;
}

public void setAdresse(String adresse) {
	this.adresse = adresse;
}

public String getTelClient() {
	return telClient;
}

public void setTelClient(String telClient) {
	this.telClient = telClient;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public int getDureeDeplacement() {
	return dureeDeplacement;
}

public void setDureeDeplacement(int dureeDeplacement) {
	this.dureeDeplacement = dureeDeplacement;
}

public int getDistanceKm() {
	return distanceKm;
}

public void setDistanceKm(int distanceKm) {
	this.distanceKm = distanceKm;
}

public ArrayList<Materiel> getLesMateriels() {
	return lesMateriels;
}

public void setLesMateriels(ArrayList<Materiel> lesMateriels) {
	this.lesMateriels = lesMateriels;
}

public ContratMaintenance getLeContrat() {
	return leContrat;
}

public void setLeContrat(ContratMaintenance leContrat) {
	this.leContrat = leContrat;
}

public String getNom() {
	return nom;
}

public void setNom(String nom) {
	this.nom = nom;
}

public String getPrenom() {
	return prenom;
}

public void setPrenom(String prenom) {
	this.prenom = prenom;
}

public String getFax() {
	return fax;
}

public void setFax(String fax) {
	this.fax = fax;
}

public String getNumeroAgence() {
	return numeroAgence;
}

public void setNumeroAgence(String numeroAgence) {
	this.numeroAgence = numeroAgence;
}
 

   
}
