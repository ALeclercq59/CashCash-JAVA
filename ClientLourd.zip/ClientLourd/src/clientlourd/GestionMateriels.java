/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientlourd;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 *
 * @author ZBoum
 */
public class GestionMateriels {

    private PersistanceSQL donnees;
    
    public GestionMateriels (PersistanceSQL donnees)
    {
    	this.donnees = donnees;
    }
    
    public Client getClient(int idClient)
    {
    	Client client = (Client)donnees.ChargerDepuisBase(Integer.toString(idClient), "Client");
		return client;
    }
    
    public String XmlClient(Client unClient){
        String xml;
        ArrayList<Materiel> listeMaterielsNonAssures = null;
        ArrayList<Materiel> listeMaterielsAssures = null;

        if(unClient.getLeContrat() != null) {
            listeMaterielsAssures = unClient.getLeContrat().getLesMaterielsAssures();
            listeMaterielsNonAssures = unClient.getLeContrat().getLesMaterielsNonAssures();
        }
        else
        {
        	listeMaterielsNonAssures = unClient.getLesMateriels();
        }

        xml = "<?xml version = \"1.0\" encoding=\"UTF-8\" ?> \n";
        xml +="<listeMateriel> \n";
        xml +="<materiels numClient=\""+unClient.getNumClient()+"\"> \n";

        if(listeMaterielsAssures != null) {
            xml +="<sousContrat> \n";
            for(Materiel m : listeMaterielsAssures) {
                xml += m.xmlMateriel(); 
            }
            xml +="</sousContrat> \n";
        }

        if(listeMaterielsNonAssures != null) {
            xml +="<horsContrat>\n";
            for(Materiel m : listeMaterielsNonAssures){
                xml += m.xmlMateriel();
            }
            xml +="</horsContrat> \n";
        }

        xml += "</materiels> \n";
        xml += "</listeMateriel> \n";
        return xml;
    }
    
    
    public static boolean XmlClientValide(String xml) throws ParserConfigurationException{

        DocumentBuilderFactory documentBuilderFactory= DocumentBuilderFactory.newInstance();
        documentBuilderFactory.setValidating(true);
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        documentBuilder.setErrorHandler(new org.xml.sax.ErrorHandler(){

            @Override
            public void error(SAXParseException arg0) throws SAXException {
            }

            @Override
            public void fatalError(SAXParseException arg0) throws SAXException {
            }

            @Override
            public void warning(SAXParseException arg0) throws SAXException {
            }

        });

        try {
            documentBuilder.parse(xml);
            return true;
        } catch (SAXException | IOException e) {
            e.printStackTrace();
            return false;
        } 
 
    }

    public void creerXml(int idClient) throws SQLException {
        Client client = getClient(idClient);
        Fichier xml = new Fichier();
        String nomFichier = "materielClient/materielClient"+client.getNumClient()+".xml";
        String xmlStr = XmlClient(client);

        try {
            xml.ouvrir(nomFichier,"e");
            xml.ecriture(xmlStr);
            xml.fermer();
            GestionMateriels.XmlClientValide(nomFichier);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
