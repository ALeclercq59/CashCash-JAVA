package clientlourd;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.swing.JOptionPane;

import java.awt.EventQueue;
import java.util.*;

public class Mail {

	   final String senderEmailID = "cashcashASJ@gmail.com";
	final String senderPassword = "cashcashASJ59";
	final String emailSMTPserver = "smtp.gmail.com";
	final String emailServerPort = "465";
	String receiverEmailID = null;
	static String emailSubject = "Test Mail";
	static String emailBody = ":)";
	  public Mail(String receiverEmailID,String Subject,String Body)
	  {
	   
	  // Receiver Email Address
	  this.receiverEmailID=receiverEmailID; 
	  // Subject
	  this.emailSubject=Subject;
	  // Body
	  this.emailBody=Body;
	  Properties props = new Properties();
	  props.put("mail.smtp.user",senderEmailID);
	  props.put("mail.smtp.host", emailSMTPserver);
	  props.put("mail.smtp.port", emailServerPort);
	  props.put("mail.smtp.starttls.enable", "true");
	  props.put("mail.smtp.auth", "true");
	  props.put("mail.smtp.socketFactory.port", emailServerPort);
	  props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	  props.put("mail.smtp.socketFactory.fallback", "false");
	  SecurityManager security = System.getSecurityManager();
      
	  try{ 
	  Authenticator auth = new SMTPAuthenticator();
	  Session session = Session.getInstance(props, auth);
	  MimeMessage msg = new MimeMessage(session);
	  msg.addRecipient(Message.RecipientType.TO,
			  new InternetAddress(receiverEmailID));
	  
	  msg.setSubject(emailSubject);
	  
	// Premi�re partie du message
	  BodyPart messageBodyPart = new MimeBodyPart();
	 messageBodyPart.setText("Bonjour, voici vos infortmations sur votre contrat");
	  
	 //Ajout de la premi�re partie du message dans un objet Multipart
	 Multipart multipart = new MimeMultipart();
	 multipart.addBodyPart(messageBodyPart);
	  
	 // Partie de la pi�ce jointe
	 messageBodyPart = new MimeBodyPart();
	 DataSource source = new FileDataSource("materielClientPDF/PDFClientRelance.pdf");
	 messageBodyPart.setDataHandler(new DataHandler(source))  ;
	 messageBodyPart.setFileName("print.pdf")  ;
	  
	 //Ajout de la partie pi�ce jointe
	 multipart.addBodyPart(messageBodyPart);
	  
	 msg.setContent(multipart);
	 Transport.send(msg);
	 
	  }
	  catch (Exception mex){
	  mex.printStackTrace();}
	  
	  }
	  
	  public class SMTPAuthenticator extends javax.mail.Authenticator
	  {
	  public PasswordAuthentication getPasswordAuthentication()
	  {
	  return new PasswordAuthentication(senderEmailID, senderPassword);
	  }
	  }
	     }

 

    

    