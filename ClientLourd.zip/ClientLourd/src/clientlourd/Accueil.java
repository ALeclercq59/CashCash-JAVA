package clientlourd;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.Window.Type;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Color;

public class Accueil {

	JFrame frame;
	private JTextField textField;
	
	static PersistanceSQL pSQL = new PersistanceSQL ("localhost", 3306, "cashcash");
	
	static ArrayList <Client> lesClients;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
				try {
					Accueil window = new Accueil();
					window.frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Accueil() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(Color.WHITE);
		frame.setResizable(false);
		frame.setBounds(100, 100, 435, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(112, 102, 196, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Num\u00E9ro Client");
		lblNewLabel.setFont(new Font("Calibri", Font.PLAIN, 17));
		lblNewLabel.setBounds(112, 68, 144, 22);
		frame.getContentPane().add(lblNewLabel);
		
		
		JButton btnNewButton = new JButton("Rechercher");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = (String) textField.getText();
					try
					{
						if (!id.isEmpty())
						{
							Client client = (Client)pSQL.ChargerDepuisBase(id, "Client");
							FicheClient c = new FicheClient(client);
							c.setVisible(true);
							frame.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null,  "Recherche vide !", "Erreur de saisie", JOptionPane.ERROR_MESSAGE);
						}
					}
					catch (Exception e1)
					{
						JOptionPane.showMessageDialog(null,  "Le client n�" + id + " n'existe pas !", "Erreur de saisie", JOptionPane.ERROR_MESSAGE);
					}
				}
		});
		btnNewButton.setFont(new Font("Calibri", Font.PLAIN, 17));
		btnNewButton.setBounds(143, 174, 126, 34);
		frame.getContentPane().add(btnNewButton);
		
		
		
		
		
		
	}
}
