package clientlourd;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ContratClient extends JFrame {

	private JPanel contentPane;
	
	private static Client c;


	/**
	 * Create the frame.
	 */
	public ContratClient(Client c) {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 613, 347);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Contrat du client n\u00B0" + c.getNumClient());
		lblNewLabel.setFont(new Font("Calibri", Font.PLAIN, 25));
		lblNewLabel.setBounds(166, 11, 330, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Num\u00E9ro Contrat : " + c.getLeContrat().getNumContrat());
		lblNewLabel_1.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(22, 103, 256, 23);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblDateSignature = new JLabel("Date Signature : " + c.getLeContrat().getDateSignature().afficheDateC());
		lblDateSignature.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblDateSignature.setBounds(22, 144, 256, 23);
		contentPane.add(lblDateSignature);
		
		JLabel lblDateEchance = new JLabel("Date Ech\u00E9ance : " + c.getLeContrat().getDateEcheance().afficheDateC());
		lblDateEchance.setFont(new Font("Calibri", Font.PLAIN, 18));
		lblDateEchance.setBounds(22, 185, 256, 23);
		contentPane.add(lblDateEchance);
		
		JButton btnNewButton = new JButton("Retour");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				FicheClient fc = new FicheClient(c);
				fc.setVisible(true);
			}
		});
		btnNewButton.setBounds(517, 284, 80, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Renouveler");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				RenouvellementContrat rc = new RenouvellementContrat(c);
				rc.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Calibri", Font.PLAIN, 18));
		btnNewButton_1.setBounds(217, 241, 149, 38);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.setVisible(false);
		
		if (!c.getLeContrat().estValide())
		{
			btnNewButton_1.setVisible(true);
		}
	}
}
