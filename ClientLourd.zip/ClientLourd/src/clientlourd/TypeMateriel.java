/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientlourd;

/**
 *
 * @author ZBoum
 */
public class TypeMateriel {
    private String referenceInterne;
    private String libelleTypeMateriel;
    private Famille laFamille;

    

	public TypeMateriel(String referenceInterne, String libelleTypeMateriel, Famille laFamille) {
		this.referenceInterne = referenceInterne;
		this.libelleTypeMateriel = libelleTypeMateriel;
		this.laFamille = laFamille;
	}

	public String getReferenceInterne() {
        return referenceInterne;
    }

    public void setReferenceInterne(String referenceInterne) {
        this.referenceInterne = referenceInterne;
    }

    public String getLibelleTypeMateriel() {
        return libelleTypeMateriel;
    }

    public void setLibelleTypeMateriel(String libelleTypeMateriel) {
        this.libelleTypeMateriel = libelleTypeMateriel;
    }

    public Famille getLaFamille() {
        return laFamille;
    }

    public void setLaFamille(Famille laFamille) {
        this.laFamille = laFamille;
    }
}
