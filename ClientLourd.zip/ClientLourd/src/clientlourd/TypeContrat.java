package clientlourd;

public class TypeContrat {
	private String refTypeContrat;
    private String delaiIntervention;
    private int tauxApplicable;


    public TypeContrat(String refTypeContrat, String delaiIntervention, int tauxApplicable) {
        this.refTypeContrat = refTypeContrat;
        this.delaiIntervention = delaiIntervention;
        this.tauxApplicable = tauxApplicable;
    }


    public String getRefTypeContrat() {
        return refTypeContrat;
    }


    public void setRefTypeContrat(String refTypeContrat) {
        this.refTypeContrat = refTypeContrat;
    }


    public String getDelaiIntervention() {
        return delaiIntervention;
    }


    public void setDelaiIntervention(String delaiIntervention) {
        this.delaiIntervention = delaiIntervention;
    }


    public int getTauxApplicable() {
        return tauxApplicable;
    }


    public void setTauxApplicable(int tauxApplicable) {
        this.tauxApplicable = tauxApplicable;
    }

}
