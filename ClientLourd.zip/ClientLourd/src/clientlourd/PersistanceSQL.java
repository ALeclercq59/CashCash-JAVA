package clientlourd;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;



public class PersistanceSQL {

    Connection connexion = null;
    Statement req = null;
    ResultSet resultat = null;
    ResultSet resultat1 = null;
    ResultSet resultat2 = null;

    public PersistanceSQL(String ipBase, int port, String nomBaseDonnees){
        try {
            Class.forName("org.gjt.mm.mysql.Driver");
            connexion = DriverManager.getConnection("jdbc:mysql://"+ipBase+":"+port+"/"+nomBaseDonnees,"root",""); // ipBase = localhost/ppe / port:3306
        }catch (Exception ex){
            System.out.println("Veuillez vous connectez � la base de donn�es !");
        }
    }

    public void RangerDansBase(Object unObjet){
    	try {
    		
    		PreparedStatement req = null;

    		switch(unObjet.getClass().getSimpleName()) {
    			case "Client":
    				Client client = (Client) unObjet;
    				req = connexion.prepareStatement("Replace INTO client VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
         	
                    req.setString(1,client.getNumClient());
                    req.setString(2, client.getPrenom());
                    req.setString(3,client.getNom());
                    req.setString(4,client.getRaisonSociale());
                    req.setString(5,client.getSiren());
                    req.setString(6,client.getCodeApe());
                    req.setString(7,client.getAdresse());
                    req.setString(8,client.getTelClient());
                    req.setString(9,client.getFax());
                    req.setString(10,client.getEmail());
                    req.setInt(11,client.getDureeDeplacement());
                    req.setInt(12,client.getDistanceKm());
                    req.setString(13,client.getNumeroAgence());
                  
                    req.executeUpdate(); 
                    
    				break;
    			
    			case "Materiel":
    				Materiel leMateriel = (Materiel) unObjet;
    				req = connexion.prepareStatement("REPLACE INTO materiel VALUES (?,?,?,?,?,?,?,?)");
            		
    				req.setInt(1,leMateriel.getNumSerie());	
    				req.setDouble(2,leMateriel.getPrixVente());
            		req.setString(3,leMateriel.getDateVente().afficheDateBDD());
            		req.setString(4,leMateriel.getDateInstallation().afficheDateBDD());
            		req.setString(5,leMateriel.getEmplacement());
            		req.setString(6,leMateriel.getLeType().getReferenceInterne());
            		req.setString(7, leMateriel.getLeClient().getNumClient());
            		req.setString(8, leMateriel.getLeContrat().getNumContrat());
            		
            		req.executeUpdate();
            		
    				break;
    			
    			case "ContratMaintenance":
    				ContratMaintenance leContrat = (ContratMaintenance) unObjet;
    				
    				req = connexion.prepareStatement("REPLACE INTO contrat_maintenance VALUES (?,?,?,?,?)");
            		req.setString(1, leContrat.getNumContrat());
                    req.setString(2, leContrat.getDateSignature().afficheDateBDD());
                    req.setString(3, leContrat.getDateEcheance().afficheDateBDD());
                    req.setString(4, leContrat.getUnClient().getNumClient());
                    req.setString(5, leContrat.getUnTypeContrat().getRefTypeContrat());
                    req.executeUpdate();
    				
    				break;
    			
    			case "TypeMateriel":
    				TypeMateriel leTypeMateriel = (TypeMateriel) unObjet;
    				
    				req = connexion.prepareStatement("REPLACE INTO type_materiel VALUES (?,?,?)");
            		req.setString(1,leTypeMateriel.getReferenceInterne());
            		req.setString(2,leTypeMateriel.getLibelleTypeMateriel());
            		req.setString(3,leTypeMateriel.getLaFamille().getCodeFamille());
            		req.executeUpdate();
    				
    				break;
    				
    			case "TypeContratMaintenance":
    				TypeContrat leTypeContratMaintenance = (TypeContrat) unObjet;
    				
    				req = connexion.prepareStatement("REPLACE INTO type_contrat VALUES (?,?,?)");
                	req.setString(1, leTypeContratMaintenance.getRefTypeContrat());
                	req.setString(2,leTypeContratMaintenance.getDelaiIntervention());
                	req.setInt(3,leTypeContratMaintenance.getTauxApplicable());
                	
                	req.executeUpdate();
                	
    				break;
    			
    			case "Famille":
    				Famille laFamille = (Famille) unObjet;
    				
    				req = connexion.prepareStatement("REPLACE INTO famille VALUES (?,?)");
            		req.setString(1,laFamille.getCodeFamille());
            		req.setString(2,laFamille.getLibelleFamille());
            		req.execute();
    				
    				break;
    						
    		}  
             
        } catch (Exception ex) {
            System.out.print(ex.getMessage());
        }
    }

    public Object ChargerDepuisBase(String id, String nomClasse){
        Object obj = null;
        try {
            req = connexion.createStatement();
            
            switch (nomClasse)
            {
            	case "Client":
            		resultat = req.executeQuery("SELECT * FROM Client WHERE numero_client = " + id);
            		while(resultat.next())
            		{
            			String numero_client = resultat.getString( "numero_client" );
            			String nom = resultat.getString( "nom" );
            			String prenom = resultat.getString( "prenom" );
            			String raisonSociale = resultat.getString( "raison_sociale" );
            			String siren = resultat.getString( "siren" );
            			String email = resultat.getString( "email" );
            			String fax = resultat.getString("fax");
            			String codeApe = resultat.getString( "code_APE" );
            			String adresse = resultat.getString( "adresse" );
            			String telClient = resultat.getString( "telephone" );
            			int dureeDeplacement = resultat.getInt( "duree_deplacement" );
            			int distanceKm = resultat.getInt( "distance_km" );
            			String numeroAgence = resultat.getString("numero_agence");
            			
            			Client client = new Client (numero_client, nom, prenom, raisonSociale, siren, codeApe, adresse, telClient, fax, email, dureeDeplacement, distanceKm, numeroAgence);
            			
            			resultat = req.executeQuery("SELECT numero_contrat FROM contrat_maintenance WHERE numero_client = " + numero_client);
            			
            			while(resultat.next())
            			{
            				String numero_contrat = resultat.getString( "numero_contrat" );
            				if (numero_contrat != "")
                			{
                				ContratMaintenance contrat = (ContratMaintenance) ChargerDepuisBase(numero_contrat, "ContratMaintenance");
                				client.setLeContrat(contrat);
                				contrat.setUnClient(client);
                			}
            			}
            			
            			
            			resultat1 = req.executeQuery("SELECT numero_serie FROM materiel WHERE numero_client = " + id);
            			
            			while(resultat1.next())
            			{
            				String numero_serie = resultat1.getString("numero_serie");
            				
            				Materiel unMateriel = (Materiel)ChargerDepuisBase(numero_serie, "Materiel");
            				
            				unMateriel.setLeClient(client);
            				
            				client.ajouteMateriel(unMateriel);
            				
            				if (client.getLeContrat() != null)
            				{
            					if (unMateriel.getLeContrat() != null)
            					{
            						client.getLeContrat().ajouteMaterielAssure(unMateriel);
            					}
            					if (unMateriel.getLeContrat() == null)
            					{
            						client.getLeContrat().getLesMaterielsNonAssures().add(unMateriel);
            					}
            				}
            			}
            			obj = client;
            		}
            	break;
            	
            	
            	case "ContratMaintenance":
                     resultat = req.executeQuery("Select * from contrat_maintenance where numero_contrat = "+ id);
                     while ( resultat.next()) 
                    {
                        String numContrat = resultat.getString( "numero_contrat" );
                        String dateSignature = resultat.getString( "date_signature" );
                        String dateEcheance = resultat.getString( "date_echeance" );
                        String numeroClient = resultat.getString("numero_client");
                        String refTypeContrat = resultat.getString( "refTypeContrat" );
                        
                        DateTp dateSignature1 = date(dateSignature);
                        DateTp dateEcheance1 = date(dateEcheance);
                        
                        TypeContrat unType = (TypeContrat) ChargerDepuisBase(refTypeContrat, "TypeContrat");
                        
                        ContratMaintenance cm = new ContratMaintenance (numContrat, dateSignature1, dateEcheance1, unType);
                        
                        obj = cm;
                    }
                break;
                
                
            	case "TypeContrat":
            		resultat = req.executeQuery("SELECT * FROM type_contrat WHERE refTypeContrat = " + id);
            		while(resultat.next())
            		{
            			String refTypeContrat = resultat.getString( "refTypeContrat" );
            			String delai_intervention = resultat.getString( "delai_intervention" );
            			int taux_applicable = resultat.getInt( "Taux_applicable" );
            			
            			obj = new TypeContrat (refTypeContrat, delai_intervention, taux_applicable);
            		}
                break;
                
            	case "Famille":
            		resultat = req.executeQuery("SELECT * FROM famille_produit WHERE code_famille = " + id);
            		while (resultat.next())
            		{
            			String code_famille = resultat.getString("code_famille");
            			String libelle = resultat.getString("libelle");
            			
            			obj = new Famille (code_famille, libelle);
            		}
                break;
                
            	case "TypeMateriel":
            		resultat = req.executeQuery("SELECT * FROM type_materiel WHERE reference = " + id);
            		while(resultat.next())
            		{
            			String reference = resultat.getString( "reference" );
                        String libelle = resultat.getString( "libelle" );
                        String code_famille = resultat.getString( "code_famille" );
                        
                        Famille famille = (Famille) ChargerDepuisBase(code_famille, "Famille");
                       
                        obj = new TypeMateriel(reference, libelle, famille);
            		}
            	break;
            		
            		
                case "Materiel":
                   resultat = req.executeQuery("Select * from materiel where numero_serie = "+ id);
                     while ( resultat.next() ) 
                    {
                        int numSerie = resultat.getInt( "numero_serie" );
                        double prix_vente = resultat.getDouble("prix_de_vente");
                        String date_vente = resultat.getString("date_de_vente" );
                        String date_installation = resultat.getString ("date_installation" );
                        String emplacement = resultat.getString( "emplacement" );
                        String reference_type = resultat.getString("reference_type");
                        String numero_contrat = resultat.getString("numero_contrat");
                        
                        DateTp date_vente1 = date(date_vente);
                        DateTp date_installation1 = date(date_installation);
                        
                        ContratMaintenance unContrat = (ContratMaintenance) ChargerDepuisBase(numero_contrat, "ContratMaintenance");
                        
                        TypeMateriel unType = (TypeMateriel) ChargerDepuisBase(reference_type, "TypeMateriel");
                        
                        Materiel materiel = new Materiel(numSerie, date_vente1, date_installation1, prix_vente, emplacement, unType);
                        
                        if (numero_contrat != null)
                        {
                        	materiel.setLeContrat(unContrat);
                        }
                        obj = materiel;
                    }
                break;
                
                
            }
            return obj;     
        } catch (SQLException ex) {
            return null;
        }
    }
    
    
    public ArrayList<Client> chargerLesClients() throws SQLException 
    {
        ArrayList<Client> lesClients = new ArrayList<>();
        Statement req = connexion.createStatement();
        ResultSet resultatClient = req.executeQuery("Select numero_client from client");

        while (resultatClient.next())
        {
            String numeroClient = resultatClient.getString( "numero_client" );
            Client unClient = (Client) ChargerDepuisBase(numeroClient,"Client");
            lesClients.add(unClient);
        }

        return lesClients;
    }
    
    
    public DateTp date (String date)
    {
    	int annee = Integer.parseInt(date.substring(0,4));
        int mois = Integer.parseInt(date.substring(5,7));
        int jour = Integer.parseInt(date.substring(8,10));
        
        DateTp result = new DateTp (annee, mois, jour);
        
    	return result;
    }
}