package clientlourd;

import java.awt.BorderLayout;

import java.util.Calendar;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import com.toedter.calendar.JDateChooser;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class RenouvellementContrat extends JFrame {

	private JPanel contentPane;
	
	PersistanceSQL pSQL = new PersistanceSQL ("localhost", 3306, "cashcash");
	
	Calendar calendar = Calendar.getInstance();
	

	/**
	 * Create the frame.
	 */
	public RenouvellementContrat(Client c) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 483, 278);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(128, 101, 187, 30);
		contentPane.add(dateChooser);
		dateChooser.setDateFormatString("dd-MM-yyyy");
		
		
		/*Date ajd = new Date();
		calendar.add(Calendar.YEAR, 1);
		dateChooser.setSelectableDateRange(ajd, calendar.getTime());*/
		calendar.add(Calendar.YEAR, 1);
		dateChooser.setDate(calendar.getTime());
		
		JButton btnNewButton = new JButton("Appliquer le renouvellement");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SimpleDateFormat formatDate = new SimpleDateFormat("dd-MM-yyyy");
                String NewDate = formatDate.format(dateChooser.getDate());
                int jour = Integer.parseInt(NewDate.substring(0,2));
                int mois = Integer.parseInt(NewDate.substring(3,5));
                int annee = Integer.parseInt(NewDate.substring(6,10));
                DateTp NewDateEcheance = new DateTp(annee, mois, jour);
                c.getLeContrat().setDateEcheance(NewDateEcheance);
                pSQL.RangerDansBase(c.getLeContrat());
                dispose();
				ContratClient cc = new ContratClient(c);
				cc.setVisible(true);
			}
		});
		btnNewButton.setBounds(122, 171, 193, 30);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Nouvelle d\u00E2te d'\u00E9ch\u00E9ance");
		lblNewLabel.setBounds(128, 74, 187, 21);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Renouvellement Contrat n\u00B0" + c.getLeContrat().getNumContrat());
		lblNewLabel_1.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel_1.setBounds(70, 11, 349, 37);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Retour");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				ContratClient cc = new ContratClient(c);
				cc.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(384, 205, 73, 23);
		contentPane.add(btnNewButton_1);
	}
}
