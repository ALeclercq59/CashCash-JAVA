package clientlourd;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JList;
import java.awt.ScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;

public class MaterielsClient extends JFrame {

	private JPanel contentPane;
	private JTable table;
	HashMap<Integer, Materiel> listeMateriels = new HashMap<Integer, Materiel>();
	

	/**
	 * Create the frame.
	 */
	public MaterielsClient(Client c) {
		PersistanceSQL pSQL = new PersistanceSQL ("localhost", 3306, "cashcash");
		
		Client c1 = (Client) pSQL.ChargerDepuisBase(c.getNumClient(), "Client");
		
		if(c1.getLeContrat() != null)
		{
			for (Materiel materiel : c1.getMaterielsHorsContrat())
			{
				listeMateriels.put(materiel.getNumSerie(), materiel);
			}
		}
		
		
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 777, 448);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Mat\u00E9riels du client n\u00B0" + c1.getNumClient());
		lblNewLabel.setFont(new Font("Calibri", Font.BOLD, 25));
		lblNewLabel.setBounds(259, 11, 368, 38);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 75, 740, 270);
		contentPane.add(scrollPane);
		
		
		
		JButton btnNewButton = new JButton("Retour");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				FicheClient fc = new FicheClient(c1);
				fc.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 11));
		btnNewButton.setBounds(689, 385, 72, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Ajouter au contrat");
		
		btnNewButton_1.setFont(new Font("Calibri", Font.PLAIN, 18));
		btnNewButton_1.setBounds(284, 370, 192, 38);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.setVisible(false);
		
		table = new JTable() { public boolean isCellEditable(int rowIndex, int colIndex) {
            return false; //Disallow the editing of any cell
		}
        };
		
		
		
		if (c1.getLeContrat() != null)
		{
			table.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					PersistanceSQL pSQL = new PersistanceSQL ("localhost", 3306, "cashcash");
					
				    int numLigne = table.getSelectedRow();
				    String etat = (String) table.getValueAt(numLigne, 5);
				    int id = (int) table.getValueAt(numLigne, 0);
				    if (etat == "Non Assur�")
				    {
				    	btnNewButton_1.setVisible(true);
				    	btnNewButton_1.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								if (listeMateriels.containsKey(id))
								{
									Materiel m1 = listeMateriels.get(id);
									c1.getMaterielsHorsContrat().remove(m1);
									c1.getLeContrat().ajouteMaterielAssure(m1);;
									if (c1.getMaterielsSousContrat().contains(m1))
									{
										table.setValueAt("Assur�", numLigne, 5);
										m1.setLeContrat(c1.getLeContrat());
										pSQL.RangerDansBase(m1);
									}
								}
							}
						});
				    }
				    else
				    {
				    	btnNewButton_1.setVisible(false);
				    }
				}
			});
		}
		
		table.setModel(new DefaultTableModel(
			new Object[][] {},
			new String[] {"N\u00B0 S\u00E9rie", "Prix", "Date de vente", "Date d'installation", "Emplacement", "Etat"}) {
			
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		scrollPane.setViewportView(table);
		
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		
		if (c1.getLeContrat() != null)
		{
			for(Materiel m : c1.getLesMateriels()) 
			{   
				if (c1.getMaterielsSousContrat().contains(m))
				{
					model.addRow(new Object [] {m.getNumSerie(), m.getPrixVente(), m.getDateVente().afficheDateC(), m.getDateInstallation().afficheDateC(), m.getEmplacement(), "Assur�" });
				}
				else
				{
					model.addRow(new Object [] {m.getNumSerie(), m.getPrixVente(), m.getDateVente().afficheDateC(), m.getDateInstallation().afficheDateC(), m.getEmplacement(), "Non Assur�" });
				}      
			}
		}
		else
		{
			for (Materiel m : c1.getLesMateriels())
			{
				model.addRow(new Object [] {m.getNumSerie(), m.getPrixVente(), m.getDateVente().afficheDateC(), m.getDateInstallation().afficheDateC(), m.getEmplacement(), "Non Assur�" });
			}
		}
		
		
		
	}
}
