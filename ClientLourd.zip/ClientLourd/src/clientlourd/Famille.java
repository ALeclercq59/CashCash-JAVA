/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientlourd;

/**
 *
 * @author ZBoum
 */
public class Famille {
    private String codeFamille;
    private String libelleFamille;
    
    public Famille (String codeFamille, String libelleFamille)
    {
    	this.codeFamille = codeFamille;
    	this.libelleFamille = libelleFamille;
    }

    public String getCodeFamille() {
        return codeFamille;
    }

    public void setCodeFamille(String codeFamille) {
        this.codeFamille = codeFamille;
    }

    public String getLibelleFamille() {
        return libelleFamille;
    }

    public void setLibelleFamille(String libelleFamille) {
        this.libelleFamille = libelleFamille;
    }
    
}
